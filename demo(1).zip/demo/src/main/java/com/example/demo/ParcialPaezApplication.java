package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParcialPaezApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParcialPaezApplication.class, args);
	}

}
